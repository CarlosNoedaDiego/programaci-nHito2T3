package com.empresahito.hito2t3carlosnoeda;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.bson.Document;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class HelloController {

    @FXML
    private TextField searchTextField;
    @FXML
    private TableView<Torre> torresTable;
    @FXML
    private TableColumn<Torre, String> nombreColumn;
    @FXML
    private TableColumn<Torre, String> pesoColumn;
    @FXML
    private TableColumn<Torre, String> tipoColumn;
    @FXML
    private TextField nombreTextField;
    @FXML
    private TextField pesoTextField;
    @FXML
    private TextField tipoTextField;

    private MongoClient mongoClient;
    private MongoCollection<Document> collection;
    private ObservableList<Torre> torresList;

    @FXML
    public void initialize() {
        // Conectar a MongoDB Atlas
        String uri = "mongodb://localhost:27017";
        mongoClient = new MongoClient(new MongoClientURI(uri));
        MongoDatabase database = mongoClient.getDatabase("Nestrum");
        collection = database.getCollection("torres");

        // Inicializar columnas de la tabla
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        pesoColumn.setCellValueFactory(new PropertyValueFactory<>("peso"));
        tipoColumn.setCellValueFactory(new PropertyValueFactory<>("tipo"));

        // Cargar datos de MongoDB
        loadTorresFromDatabase();

        // Enlazar la lista de torres con la tabla
        torresTable.setItems(torresList);
    }

    private void loadTorresFromDatabase() {
        List<Torre> torres = StreamSupport.stream(collection.find().spliterator(), false)
                .map(doc -> new Torre(doc.getString("nombre"), doc.getString("peso"), doc.getString("tipo")))
                .collect(Collectors.toList());
        torresList = FXCollections.observableArrayList(torres);
    }

    @FXML
    protected void handleCreate() {
        String nombre = nombreTextField.getText();
        String peso = pesoTextField.getText();
        String tipo = tipoTextField.getText();

        Torre torre = new Torre(nombre, peso, tipo);
        torresList.add(torre);
        collection.insertOne(new Document("nombre", nombre).append("peso", peso).append("tipo", tipo));
        clearFields();
    }

    @FXML
    protected void handleUpdate() {
        Torre selectedTorre = torresTable.getSelectionModel().getSelectedItem();
        if (selectedTorre != null) {
            String nombre = nombreTextField.getText();
            String peso = pesoTextField.getText();
            String tipo = tipoTextField.getText();

            selectedTorre.setNombre(nombre);
            selectedTorre.setPeso(peso);
            selectedTorre.setTipo(tipo);

            collection.updateOne(new Document("nombre", selectedTorre.getNombre()),
                    new Document("$set", new Document("peso", peso).append("tipo", tipo)));
            torresTable.refresh();
            clearFields();
        }
    }

    @FXML
    protected void handleDelete() {
        Torre selectedTorre = torresTable.getSelectionModel().getSelectedItem();
        if (selectedTorre != null) {
            torresList.remove(selectedTorre);
            collection.deleteOne(new Document("nombre", selectedTorre.getNombre()));
            clearFields();
        }
    }

    private void clearFields() {
        nombreTextField.clear();
        pesoTextField.clear();
        tipoTextField.clear();
    }
}
