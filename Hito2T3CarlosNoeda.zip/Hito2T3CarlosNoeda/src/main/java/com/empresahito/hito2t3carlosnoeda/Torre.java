package com.empresahito.hito2t3carlosnoeda;

public class Torre {
    private String nombre;
    private String peso;
    private String tipo;

    public Torre(String nombre, String peso, String tipo) {
        this.nombre = nombre;
        this.peso = peso;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
