module com.empresahito.hito2t3carlosnoeda {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.empresahito.hito2t3carlosnoeda to javafx.fxml;
    exports com.empresahito.hito2t3carlosnoeda;
}